/* HelloWorld!!! 
*     Your first program.
*/

/* This is a HEADER file:  it tells the compiler what arguments and return
   value are for the print function, printf.
   Here is what I found at /usr/include/stdio.h
	int      printf __P((const char *, ...));
*/

#include<stdio.h>

int main(void) {

      printf("%s\n","HelloWorld!!!");
      exit(1);

 }

